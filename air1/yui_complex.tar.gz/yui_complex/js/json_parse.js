/*
    json_parse.js

    Public Domain

    JSON_parse(text) takes a JSON text and produces a JavaScript value.
    It will throw SyntaxError if there is an error in parsing the JSON
    text. This function can be significantly slower than eval.

*/

/*members at, charAt, fromCharCode, message, name, push, text */

var json_parse = function (text) {

    var at = 0,     // The index of the current character
        ch = ' ',   // The current character
        result,     // The final result
        value;      // The value function

    var error = function (m) {
        throw {
            name: 'SyntaxError',
            message: m,
            at: at,
            text: text
        };
    };

    var next = function () {
/*
    Get the next character. When there are no more characters,
    return the empty string.
*/
        ch = text.charAt(at);
        at += 1;
        return ch;
    };

    var white = function () {
        while (ch && ch <= ' ') {
            next();
        }
    };

    var string = function () {
        var i,          // loop counter
            h,          // a hex value
            s = '',     // the string value
            u;          // a character code made from 4 hex digits

/*
    When parsing for string values, we must look for " and \ characters.
*/

        if (ch === '"') {
    outer:  while (next()) {
                if (ch === '"') {
                    next();
                    return s;
                } else if (ch === '\\') {
                    switch (next()) {
                    case 'b':
                        s += '\b';
                        break;
                    case 'f':
                        s += '\f';
                        break;
                    case 'n':
                        s += '\n';
                        break;
                    case 'r':
                        s += '\r';
                        break;
                    case 't':
                        s += '\t';
                        break;
                    case 'u':
                        u = 0;
                        for (i = 0; i < 4; i += 1) {
                            h = parseInt(next(), 16);
                            if (!isFinite(h)) {
                                break outer;
                            }
                            u = u * 16 + h;
                        }
                        s += String.fromCharCode(u);
                        break;
                    default:
                        s += ch;
                    }
                } else {
                    s += ch;
                }
            }
        }
        error("Bad string");
    };

    var array = function () {
        var a = [];     // The array value result

        if (ch === '[') {
            next();
            white();
            if (ch === ']') {
                next();
                return a;   // empty array
            }
            while (ch) {
                a.push(value());
                white();
                if (ch === ']') {
                    next();
                    return a;
                } else if (ch !== ',') {
                    break;
                }
                next();
                white();
            }
        }
        error("Bad array");
    };

    var object = function () {
        var k,          // The current key
            o = {};     // The object value result

        if (ch === '{') {
            next();
            white();
            if (ch === '}') {
                next();
                return o;   // empty object
            }
            while (ch) {
                k = string();
                white();
                if (ch !== ':') {
                    break;
                }
                next();
                o[k] = value();
                white();
                if (ch === '}') {
                    next();
                    return o;
                } else if (ch !== ',') {
                    break;
                }
                next();
                white();
            }
        }
        error("Bad object");
    };

    var number =function () {
        var n = '',     // the number string
            v;          // the number value result

        if (ch === '-') {
            n = '-';
            next();
        }
        while (ch >= '0' && ch <= '9') {
            n += ch;
            next();
        }
        if (ch === '.') {
            n += '.';
            while (next() && ch >= '0' && ch <= '9') {
                n += ch;
            }
        }
        if (ch === 'e' || ch === 'E') {
            n += 'e';
            next();
            if (ch === '-' || ch === '+') {
                n += ch;
                next();
            }
            while (ch >= '0' && ch <= '9') {
                n += ch;
                next();
            }
        }
        v = +n;
        if (!isFinite(v)) {
            error("Bad number");
        } else {
            return v;
        }
    };

    var word = function () {
        switch (ch) {
        case 't':
            if (next() === 'r' && next() === 'u' && next() === 'e') {
                next();
                return true;
            }
            break;
        case 'f':
            if (next() === 'a' && next() === 'l' && next() === 's' &&
                    next() === 'e') {
                next();
                return false;
            }
            break;
        case 'n':
            if (next() === 'u' && next() === 'l' && next() === 'l') {
                next();
                return null;
            }
            break;
        }
        error("Syntax error");
    };

    value = function () {
        white();
        switch (ch) {
        case '{':
            return object();
        case '[':
            return array();
        case '"':
            return string();
        case '-':
            return number();
        default:
            return ch >= '0' && ch <= '9' ? number() : word();
        }
    };

    result = value();
    white();
    if (ch) {
        error("Syntax error");
    }
    return result;
};
