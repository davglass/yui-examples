(function() {
    YAHOO.log('editor.js file loaded', 'info', 'editor.js');
    YAHOO.log('Inject some HTML for the Compose Window', 'info', 'editor.js');
    YAHOO.util.Dom.get('composeViewEl').innerHTML = '<div id="composeBarWrap"><div id="composeBar"></div><div id="composeAddr"><span><label>To:</label><input type="text" id="composeTo"></span><span><label>Subject:</label><input type="text"></span></div></div><text'+'area id="compose"></text'+'area><div id="autoTo"></div>';
    //Use loader to load the Editor
    var loader = new YAHOO.util.YUILoader({
        base: 'yui/',
        require: ['autocomplete', 'editor'],
        ignore: ['containercore'],
        onSuccess: function() {
            YAHOO.log('Create a Toolbar above the To/From Fields', 'info', 'editor.js');
            YAHOO.example.app.composeToolbar = new YAHOO.widget.Toolbar('composeBar', {
                buttons: [
                    { id: 'tb_delete', type: 'push', label: 'Send', value: 'send'},
                    { id: 'tb_reply', type: 'push', label: 'Attach', value: 'attach' },
                    { id: 'tb_forward', type: 'push', label: 'Save Draft', value: 'savedraft' },
                    { id: 'tb_forward', type: 'push', label: 'Spelling', value: 'spelling' },
                    { id: 'tb_forward', type: 'push', label: 'Cancel', value: 'cancel' }
                ]
            });
            //Show an alert message with the button they clicked            
            YAHOO.example.app.composeToolbar.on('buttonClick', function(ev) {
                YAHOO.example.app.alert('You clicked: ' + ev.button.label);
            });
            
            //Editor startResize method - Disables the editor so we can drga over it.
            var editorStartResize = function() {
                YAHOO.example.app.editor.set('disabled', true);
            };
            //Custom editor resize method
            var editorResize = function() {
                var h = YAHOO.util.Dom.get('composeViewEl').parentNode.clientHeight - (YAHOO.util.Dom.get('composeBarWrap').clientHeight);
                var th = YAHOO.example.app.editor.toolbar.get('element').clientHeight;
                var newH = (h - th);
                YAHOO.example.app.editor.set('height', newH + 'px');
                YAHOO.example.app.editor.set('width', YAHOO.example.app.layout.getSizes().center.w + 'px');
                YAHOO.example.app.editor.set('disabled', false);
            };
            YAHOO.log('Create the Editor', 'info', 'editor.js');
            var editor = new YAHOO.widget.Editor('compose', {
                width: (YAHOO.example.app.layout.getUnitByPosition('center').getSizes().body.w - 2) + 'px'
            });
            editor.on('afterRender', function() {
                YAHOO.log('The editor is loaded, resize the editor to fit the layout', 'info', 'editor.js');
                var h = YAHOO.util.Dom.get('composeViewEl').parentNode.clientHeight - (YAHOO.util.Dom.get('composeBarWrap').clientHeight);
                var th = this.toolbar.get('element').clientHeight;
                var newH = (h - th);
                this.set('height', newH + 'px');
            }, editor, true);
            /* {{{ ADOBE AIR UNSUPPORTED HACK */
            editor.browser.webkit = true;
            editor.browser.webkit3 = true;
            editor._setInitialContent = function() {
                var Lang = YAHOO.lang;
                YAHOO.log('Populating editor body with contents of the text area', 'info', 'SimpleEditor');
                var html = Lang.substitute(this.get('html'), {
                    TITLE: this.STR_TITLE,
                    CONTENT: this._cleanIncomingHTML(this.get('element').value),
                    CSS: this.get('css'),
                    HIDDEN_CSS: ((this.get('hiddencss')) ? this.get('hiddencss') : '/* No Hidden CSS */'),
                    EXTRA_CSS: ((this.get('extracss')) ? this.get('extracss') : '/* No Extra CSS */')
                }),
                check = true;
                if (document.compatMode != 'BackCompat') {
                    YAHOO.log('Adding Doctype to editable area', 'info', 'SimpleEditor');
                    html = this._docType + "\n" + html;
                } else {
                    YAHOO.log('DocType skipped because we are in BackCompat Mode.', 'warn', 'SimpleEditor');
                }

                if (this.browser.ie || this.browser.webkit || this.browser.opera || (navigator.userAgent.indexOf('Firefox/1.5') != -1)) {
                    //Firefox 1.5 doesn't like setting designMode on an document created with a data url
                    try {
                        var doc = this._getDoc().implementation.createHTMLDocument();
                        var origDoc = this._getDoc();
                        doc.open();doc.write(html);doc.close();
                        var node = origDoc.importNode(doc.getElementsByTagName("html")[0], true);
                        origDoc.replaceChild(node, origDoc.getElementsByTagName("html")[0]);
                        origDoc.body._rteLoaded = true;
                    } catch (e) {
                        YAHOO.log('Setting doc failed.. (_setInitialContent)', 'error', 'SimpleEditor');
                        //Safari will only be here if we are hidden
                        check = false;
                    }
                } else {
                    //This keeps Firefox 2 from writing the iframe to history preserving the back buttons functionality
                    this.get('iframe').get('element').src = 'data:text/html;charset=utf-8,' + encodeURIComponent(html);
                }
                if (check) {
                    this._checkLoaded();
                }
            },

            /* }}} */
            //Turn off the titlebar
            editor._defaultToolbar.titlebar = false;
            YAHOO.log('Render the editor', 'info', 'editor.js');
            editor.render();
            YAHOO.example.app.editor = editor;

            //On resize and start resize handlers
            YAHOO.example.app.layout.on('startResize', editorStartResize);
            YAHOO.example.app.layout.on('resize', editorResize);
            //Method to destroy the editor.
            YAHOO.example.app.destroyEditor = function() {
                YAHOO.log('Destroying the Editor instance and HTML', 'info', 'editor.js');
                YAHOO.example.app.layout.unsubscribe('startResize', editorStartResize);
                YAHOO.example.app.layout.unsubscribe('resize', editorResize);
                YAHOO.example.app.editor = null;
            };

            YAHOO.log('Setup the AutoComplete for the To Field', 'info', 'editor.js');
            //Build some fake data..
            var team = [
                'Dav',
                'Thomas',
                'Eric',
                'Matt',
                'Adam',
                'Lucas',
                'Nate',
                'Jenny',
                'Satyen',
                'Todd',
                'George'
            ], data = [];

            for (var i = 0; i < team.length; i++) {
                for (var s = 0; s < 5; s++) {
                    data[data.length] = team[i] + ' (' + s + ') [' + team[i].toLowerCase() + '@yui.com]';
                }
            }
            // Instantiate JS Array DataSource
            var oACDS2 = new YAHOO.widget.DS_JSArray(data);
            YAHOO.log('Instantiate AutoComplete', 'info', 'editor.js');
            var oAutoComp = new YAHOO.widget.AutoComplete('composeTo','autoTo', oACDS2);
            oAutoComp.prehighlightClassName = "yui-ac-prehighlight";
            oAutoComp.typeAhead = true;
            oAutoComp.useIFrame = true;
        }
    });
    //Have loader only insert the js files..
    loader.insert({}, 'js');
})();
