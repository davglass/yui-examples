(function() {
    YAHOO.example.app.getAirData = function(url, callback) {
        var request = new air.URLRequest(url);
        var variables = new air.URLLoader();
        variables.dataFormat = air.URLLoaderDataFormat.TEXT;
        variables.addEventListener(air.Event.COMPLETE, function(ev) {
            var loader = ev.target;
            var d = json_parse(loader.data);
            callback(d);
        });
        variables.load(request);
        
    };
    //Hijack the links at the top
    YAHOO.util.Event.onAvailable('searchBox', function() {
        YAHOO.util.Event.on(YAHOO.util.Selector.query('#searchBox span.links a'), 'click', function(ev) {
            YAHOO.util.Event.stopEvent(ev);
            air.navigateToURL(new air.URLRequest(this.href));
        });
    });
    YAHOO.util.Event.onAvailable('newsSports', function() {
        YAHOO.util.Event.on('news', 'click', function(ev) {
            var tar = YAHOO.util.Event.getTarget(ev);
            if (YAHOO.util.Selector.test(tar, '#news .yui-content ul li a') || YAHOO.util.Selector.test(tar, '#news .yui-content h3 a') || YAHOO.util.Selector.test(tar, '#news .yui-content p a')) {
                if (tar.className != 'moreNews') {
                    YAHOO.util.Event.stopEvent(ev);
                    air.navigateToURL(new air.URLRequest(tar.href));
                }
            }
        });
    });
})();
