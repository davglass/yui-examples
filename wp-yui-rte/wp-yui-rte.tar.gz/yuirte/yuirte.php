<?php
/*
Plugin Name: WP YUI Rich Text Editor
Plugin URI: http://blog.davglass.com/files/yui/wp-yui-rte
Description: Include the YUI Rich Text Editor on blog posts and comments. YUI Version 2.4.0
Version: 1.6.1 (Beta)
Author: Dav Glass <dav.glass@yahoo.com>
Author URI: http://blog.davglass.com/
*/

//Change this to true to activate the RTE on blog comments..
$rte_comments = false;

$yuiVersion = '2.4.0';

function yuirte_prep($ac=false) {
global $yuiVersion;
if ($ac) {
?>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/utilities/utilities.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/autocomplete/autocomplete-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/container/container_core-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/menu/menu-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/button/button-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/editor/editor-beta-min.js"></script>
<?php
} else {
?>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/yahoo-dom-event/yahoo-dom-event.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/element/element-beta-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/container/container_core-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/button/button-min.js"></script>
<script language="javascript" type="text/javascript" src="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/editor/simpleeditor-beta-min.js"></script>
<?php
}
}

function yuirte() {
global $yuiVersion;
    ?>
<link rel="stylesheet" href="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/assets/skins/sam/skin.css" type="text/css" />
<link rel="stylesheet" href="<?php echo get_settings('siteurl'); ?>/wp-content/plugins/yuirte/yuirte.css" type="text/css" />
    <?php
    yuirte_prep(true);
    ?>
<script>
    YAHOO.namespace('YUI_RTE');

    YAHOO.YUI_RTE.mobilePhone = false;

    if (RegExp(" AppleWebKit/").test(navigator.userAgent)) {
        if (RegExp(" Mobile/").test(navigator.userAgent)) {
            YAHOO.YUI_RTE.mobilePhone = true; //iPhone
        }
        if (RegExp(" NokiaN95/").test(navigator.userAgent)) {
            YAHOO.YUI_RTE.mobilePhone = true; //Nokia N95
        }
    }
    
    YAHOO.YUI_RTE.baseURL = '<?php echo get_settings('siteurl'); ?>/wp-content/plugins/yuirte/';
    <?php
        echo('YAHOO.YUI_RTE.canEdit = '.((user_can_richedit_yui()) ? 'true' : 'false').';'."\n");
    ?>
</script>
<script language="javascript" type="text/javascript" src="<?php echo get_settings('siteurl'); ?>/wp-content/plugins/yuirte/yuirte-min.js"></script>
    <?php
}

add_action('edit_form_advanced','yuirte');
add_action('edit_page_form','yuirte');
add_action('simple_edit_form','yuirte');

if ($rte_comments) {
    add_action('wp_head','yuirte_comments');
}



function yui_rte_head() {
global $wp_scripts;
if ($wp_scripts) {
    $wp_scripts->remove(array('tiny_mce'));
}
?>
<script>
//Override the default WordPress/TinyMCE bindings (They really shouldn't make me do this!!)
var tinyMCE = {
    configs: [],
    isMSIE: false,
    getInstanceById: function() {
        return undefined
    }
};
</script>
<?php
}
add_action('wp_print_scripts',   'yui_rte_head');


function user_can_richedit_yui() { //Mimic the user_can_richedit function but remove the stupid userAgent check
    global $wp_rich_edit, $pagenow;
    $wp_rich_edit = ( 'true' == get_user_option('rich_editing') && 'comment.php' != $pagenow ) ? true : false;

    return apply_filters('user_can_richedit', $wp_rich_edit);
}


function yuirte_comments() {
global $yuiVersion;
    yuirte_prep();
    ?>
<script>
    YAHOO.namespace('YUI_RTE');

    YAHOO.YUI_RTE.mobilePhone = false;

    if (RegExp(" AppleWebKit/").test(navigator.userAgent)) {
        if (RegExp(" Mobile/").test(navigator.userAgent)) {
            YAHOO.YUI_RTE.mobilePhone = true; //iPhone
        }
        if (RegExp(" NokiaN95/").test(navigator.userAgent)) {
            YAHOO.YUI_RTE.mobilePhone = true; //Nokia N95
        }
    }
    YAHOO.YUI_RTE.baseURL = '<?php echo get_settings('siteurl'); ?>/wp-content/plugins/yuirte/';
</script>
<link rel="stylesheet" href="http://yui.yahooapis.com/<?php echo($yuiVersion); ?>/build/assets/skins/sam/skin.css" type="text/css" />
<script language="javascript" type="text/javascript" src="<?php echo get_settings('siteurl'); ?>/wp-content/plugins/yuirte/yuirte_comments-min.js"></script>
<?php
}
?>
