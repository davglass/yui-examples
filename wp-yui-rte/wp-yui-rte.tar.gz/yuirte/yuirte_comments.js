(function() {
    if (YAHOO.YUI_RTE.mobilePhone === false) {
        var Dom = YAHOO.util.Dom,
            Event = YAHOO.util.Event;

        Event.onAvailable('comment', function() {
            YAHOO.YUI_RTE.Editor = new YAHOO.widget.SimpleEditor('comment', {
                height: '200px',
                width: '522px',
                markup: 'xhtml',
                toolbar: {
                    titlebar: false,
                    buttons: [
                        { group: 'textstyle', label: 'Font Style',
                            buttons: [
                                { type: 'push', label: 'Bold', value: 'bold' },
                                { type: 'push', label: 'Italic', value: 'italic' },
                                { type: 'push', label: 'Underline', value: 'underline' },
                                { type: 'separator' },
                                { type: 'select', label: 'Arial', value: 'fontname', disabled: true,
                                    menu: [
                                        { text: 'Arial', checked: true },
                                        { text: 'Arial Black' },
                                        { text: 'Comic Sans MS' },
                                        { text: 'Courier New' },
                                        { text: 'Lucida Console' },
                                        { text: 'Tahoma' },
                                        { text: 'Times New Roman' },
                                        { text: 'Trebuchet MS' },
                                        { text: 'Verdana' }
                                    ]
                                },
                                { type: 'spin', label: '13', value: 'fontsize', range: [ 9, 75 ], disabled: true },
                                { type: 'separator' },
                                { type: 'push', label: 'Create an Unordered List', value: 'insertunorderedlist' },
                                { type: 'push', label: 'Create an Ordered List', value: 'insertorderedlist' },
                                { type: 'separator' },
                                { type: 'color', label: 'Font Color', value: 'forecolor', disabled: true },
                                { type: 'color', label: 'Background Color', value: 'backcolor', disabled: true }
                                
                            ]
                        }
                    ]
                }
            });
            YAHOO.YUI_RTE.Editor.on('toolbarLoaded', function() {
                YAHOO.YUI_RTE.Editor.toolbar.set('grouplabels', false);
            });
            YAHOO.YUI_RTE.Editor.render();
            
            Event.onAvailable('submit', function() {
                var par = Dom.get('submit').parentNode;
                par.removeChild(Dom.get('submit'));
                Dom.setStyle(par, 'text-align', 'right');
                
                var _button = new YAHOO.widget.Button({
                    id: 'submit_comment',
                    label: 'Submit Comment',
                    value: 'submitcomment',
                    container: par
                });

                _button.on('click', function() {
                    //Needed for Safari - Not sure why, Bug submitted..
                    Dom.setStyle('comment', 'visibility', 'hidden');
                    Dom.setStyle('comment', 'position', 'absolute');
                    Dom.setStyle('comment', 'display', 'block');
                    YAHOO.YUI_RTE.Editor.saveHTML();
                    window.setTimeout(function() {
                            Dom.get('commentform').submit();
                    }, 200);
                });

                //Not sure why this is needed.. Need to Investigate..
                window.setTimeout(function() {
                    var _button = new YAHOO.widget.Button({
                        id: 'test_this',
                        label: 'Test',
                        value: 'Test',
                        container: par
                    });
                    _button.destroy();
                }, 5);
            });

            Event.onDOMReady(function() {
                Dom.addClass(document.body, 'yui-skin-sam');
            });
        });
    }
})();

