if (YAHOO.YUI_RTE.canEdit && (YAHOO.YUI_RTE.mobilePhone === false)) {
    /* Gutter Plugin */
    (function() {
        var Dom = YAHOO.util.Dom,
            Event = YAHOO.util.Event;

        YAHOO.gutter = function() {
            return {
                status: false,
                gutter: null,
                createGutter: function() {
                    YAHOO.log('Creating gutter (#gutter1)', 'info', 'example');
                    this.gutter = new YAHOO.widget.Overlay('gutter1', {
                        height: '425px',
                        width: '260px',
                        iframe: true,
                        context: [YAHOO.YUI_RTE.Editor.get('element_cont').get('element'), 'tl', 'tr'],
                        position: 'absolute',
                        visible: false
                    });
                    this.gutter.hideEvent.subscribe(function() {
                        YAHOO.YUI_RTE.Editor.toolbar.deselectButton(YAHOO.YUI_RTE.Editor.toolbar.getButtonByValue('flickr'));
                        Dom.setStyle('gutter1', 'visibility', 'visible');                
                        var anim = new YAHOO.util.Anim('gutter1', {
                            width: {
                                from: 260,
                                to: 0
                            },
                            opacity: {
                                from: 1,
                                to: 0
                            }
                        }, 1);
                        anim.onComplete.subscribe(function() {  
                            Dom.setStyle('gutter1', 'visibility', 'hidden');
                            Dom.setStyle('gutter1', 'display', 'none');
                        });
                        anim.animate();
                    }, this, true);
                    this.gutter.showEvent.subscribe(function() {
                        YAHOO.YUI_RTE.Editor.toolbar.selectButton(YAHOO.YUI_RTE.Editor.toolbar.getButtonByValue('flickr'));
                        this.gutter.cfg.setProperty('context', [YAHOO.YUI_RTE.Editor.get('element_cont').get('element'), 'tl', 'tr']);
                        Dom.setStyle(this.gutter.element, 'width', '0px');
                        Dom.setStyle(this.gutter.element, 'display', 'block');
                        var anim = new YAHOO.util.Anim('gutter1', {
                            width: {
                                from: 0,
                                to: 260
                            },
                            opacity: {
                                from: 0,
                                to: 1
                            }
                        }, 1);
                        anim.animate();
                    }, this, true);
                    var warn = '';
                    if (YAHOO.YUI_RTE.Editor.browser.webkit || YAHOO.YUI_RTE.Editor.browser.opera) {
                        warn = YAHOO.YUI_RTE.Editor.STR_IMAGE_COPY;
                    }
                    this.gutter.setBody('<h2>Flickr Image Search</h2><label for="flikr_search">Tag:</label><input type="text" value="" id="flickr_search"><div id="flickr_results"><p>Enter flickr tags into the box above, seperated by commas. Be patient, this example my take a few seconds to get the images..</p></div>' + warn);
                    this.gutter.render(document.body);
                },
                open: function() {
                    Dom.get('flickr_search').value = '';
                    YAHOO.log('Show Gutter', 'info', 'example');
                    this.gutter.show();
                    this.status = true;
                },
                close: function() {
                    YAHOO.log('Close Gutter', 'info', 'example');
                    this.gutter.hide();
                    this.status = false;
                },
                toggle: function() {
                    if (this.status) {
                        this.close();
                    } else {
                        this.open();
                    }
                }
            };
        };
    })();

    YAHOO.util.Event.onAvailable('flickr_search', function() {
        YAHOO.log('onAvailable: #flickr_search', 'info', 'example');
        YAHOO.util.Event.on('flickr_results', 'mousedown', function(ev) {
            YAHOO.util.Event.stopEvent(ev);
            var tar = YAHOO.util.Event.getTarget(ev);
            if (tar.tagName.toLowerCase() == 'img') {
                if (tar.getAttribute('fullimage', 2)) {
                    YAHOO.log('Found an image, insert it..', 'info', 'example');
                    var img = tar.getAttribute('fullimage', 2),
                        title = tar.getAttribute('fulltitle'),
                        owner = tar.getAttribute('fullowner'),
                        url = tar.getAttribute('fullurl');
                    this.toolbar.fireEvent('flickrClick', { type: 'flickrClick', img: img, title: title, owner: owner, url: url });
                }
            }
        }, YAHOO.YUI_RTE.Editor, true);
        YAHOO.log('Create the Auto Complete Control', 'info', 'example');
        var oACDS = new YAHOO.widget.DS_XHR(YAHOO.YUI_RTE.baseURL + "assets/flickr_proxy.php",
            ["photo", "title", "id", "owner", "secret", "server"]);
        oACDS.scriptQueryParam = "tags";
        oACDS.responseType = YAHOO.widget.DS_XHR.TYPE_XML;
        oACDS.maxCacheEntries = 0;
        oACDS.scriptQueryAppend = "method=flickr.photos.search";

        // Instantiate AutoComplete
        var oAutoComp = new YAHOO.widget.AutoComplete('flickr_search','flickr_results', oACDS);
        oAutoComp.autoHighlight = false;
        oAutoComp.alwaysShowContainer = true; 
        oAutoComp.formatResult = function(oResultItem, sQuery) {
            // This was defined by the schema array of the data source
            var sTitle = oResultItem[0];
            var sId = oResultItem[1];
            var sOwner = oResultItem[2];
            var sSecret = oResultItem[3];
            var sServer = oResultItem[4];
            var urlPart = 'http:/'+'/static.flickr.com/' + sServer + '/' + sId + '_' + sSecret;
            var sUrl = urlPart + '_s.jpg';
            var lUrl = urlPart + '_m.jpg';
            var fUrl = 'http:/'+'/www.flickr.com/photos/' + sOwner + '/' + sId;
            var sMarkup = '<img src="' + sUrl + '" fullimage="' + lUrl + '" fulltitle="' + sTitle + '" fullid="' + sOwner + '" fullurl="' + fUrl + '" class="yui-ac-flickrImg" title="Click to add this image to the editor"><br>';
            return (sMarkup);
        };
    });

    var gutter = null;

    (function() {
        var Dom = YAHOO.util.Dom,
            Event = YAHOO.util.Event,
            _saveButton = new YAHOO.widget.Button('save'),
            _submitButton = new YAHOO.widget.Button(document.getElementsByName('submit')[0]),
            _pubButton = new YAHOO.widget.Button('publish');

        YAHOO.YUI_RTE.Editor = new YAHOO.widget.Editor('content', {
            dompath: true,
            height: '350px',
            animate: true
        });
        YAHOO.YUI_RTE.Editor.on('toolbarLoaded', function() { 
            gutter = new YAHOO.gutter();
            var flickrConfig = {
                    type: 'push',
                    label: 'Insert Flickr Image',
                    value: 'flickr'
            };
            //Remove the toolbar
            YAHOO.YUI_RTE.Editor.toolbar.set('titlebar', false);

            YAHOO.YUI_RTE.Editor.toolbar.addButtonToGroup(flickrConfig, 'insertitem');

            YAHOO.YUI_RTE.Editor.toolbar.on('flickrClick', function(ev) {
                this._getWindow().focus();
                if (ev && ev.img) {
                    //To abide by the Flickr TOS, we need to link back to the image that we just inserted
                    var html = '<a href="' + ev.url + '"><img src="' + ev.img + '" title="' + ev.title + '"></a>';
                    this.execCommand('inserthtml', html);
                }
                gutter.toggle();
            }, YAHOO.YUI_RTE.Editor, true);
            gutter.createGutter();
        });
        YAHOO.YUI_RTE.Editor.render();

        var form = Dom.get('post');
        var submitForm = function(ev) {
            Event.stopEvent(ev);
            this.saveHTML();
            window.setTimeout(function() {
                var form = YAHOO.util.Dom.get('post');
                YAHOO.util.Event.removeListener(form, 'submit', submitForm);
                if (YAHOO.env.ua.ie) {        
                    form.fireEvent("onsubmit");
                } else {  // Gecko, Opera, and Safari
                    var oEvent = document.createEvent("HTMLEvents");
                    oEvent.initEvent("submit", true, true);
                    form.dispatchEvent(oEvent);
                }
                if (YAHOO.env.ua.ie || YAHOO.env.ua.webkit) {
                    form.submit();
                }
            }, 200);
        };
        Event.on(form, 'submit', submitForm, YAHOO.YUI_RTE.Editor, true);

        Event.onDOMReady(function() {
            var showingEditor = true;
            Dom.addClass(document.body, 'yui-skin-sam');
            Dom.get('edButtons').innerHTML = '';
            Dom.setStyle('edButtons', 'display', 'block');
            var _button = new YAHOO.widget.Button({
                label: 'Hide the Editor',
                container: 'edButtons'
            });
            _button.on('click', function() {
                if (showingEditor) {
                    _button.set('label', 'Show the Editor');
                    YAHOO.util.Dom.setStyle('quicktags', 'display', 'block');
                    YAHOO.YUI_RTE.Editor.saveHTML();
                    YAHOO.YUI_RTE.Editor.hide();
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element_cont').get('firstChild'), 'position', 'absolute');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element_cont').get('firstChild'), 'top', '-9999px');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element_cont').get('firstChild'), 'left', '-9999px');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'position', 'static');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'top', '');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'left', '');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'visibility', 'visible');
                    showingEditor = false;
                    Event.removeListener(form, 'submit', submitForm);
                } else {
                    _button.set('label', 'Hide the Editor');
                    YAHOO.util.Dom.setStyle('quicktags', 'display', 'none');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element_cont').get('firstChild'), 'position', 'static');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element_cont').get('firstChild'), 'top', '0');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element_cont').get('firstChild'), 'left', '0');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'position', 'absolute');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'top', '-9999px');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'left', '-9999px');
                    Dom.setStyle(YAHOO.YUI_RTE.Editor.get('element'), 'visibility', 'hidden');
                    YAHOO.YUI_RTE.Editor.show();
                    YAHOO.YUI_RTE.Editor.setEditorHTML(YAHOO.YUI_RTE.Editor.get('textarea').value);
                    YAHOO.YUI_RTE.Editor._focusWindow();
                    showingEditor = true;
                    Event.on(form, 'submit', submitForm, YAHOO.YUI_RTE.Editor, true);
                }
            });
        });
        
        Event.onAvailable('title', function() {
            var evType = 'keypress';
            if (YAHOO.env.ua.ie) {
                evType = 'keydown';
            }
            Event.on('title', evType, function(ev) {
                if (ev.keyCode == 9 && !ev.shiftKey && !ev.controlKey && !ev.altKey) {
                    Event.stopEvent(ev);
                    YAHOO.YUI_RTE.Editor._getWindow().focus();
                }
            }, YAHOO.YUI_RTE, true);
        }, YAHOO.YUI_RTE, true);
        

    })();
} else {
    YAHOO.util.Event.onDOMReady(function() {
        YAHOO.util.Dom.setStyle('quicktags', 'display', 'block');
    });
}
